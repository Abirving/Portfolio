﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AK_Hospital.Domain_Classes
{
    internal class Medications
    {
        public int Medicationid { get; set; }
        public string MedicationName { get; set; }
        public string PrescribedFor { get; set; }
    }
}
