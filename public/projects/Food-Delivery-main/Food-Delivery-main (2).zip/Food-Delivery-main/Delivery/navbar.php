<nav>
    <span class="title">Delivery Interface</span>
        <ul>
            <li><a href="DashBoard.php">
                <i class="fa-solid fa-home"></i>
                Home</a>
            </li>
            <li><a href="Orders.php">
                <i class="fa-solid fa-shop"></i>
                View Orders</a>
            </li>
            <li><a href="Account.php">
            <i class="fa-solid fa-user-large"></i>
                Account</a>
            </li>
        </ul>
</nav>