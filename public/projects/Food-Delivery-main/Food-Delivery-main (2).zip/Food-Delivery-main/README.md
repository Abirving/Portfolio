# Food-Delivery

## This is not a production ready website, for demo purpose's only

Final project for Internet Programming.

Language's used: HTML, CSS, PHP, MySQL & a bit of Javascript

Requiremnts to run: WampServer(or any web development environment that can run PHP & MySQL)


