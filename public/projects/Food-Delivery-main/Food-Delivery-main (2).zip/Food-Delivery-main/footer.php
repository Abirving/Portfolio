<footer id="footer" class="grid center">
    <div class="bg-white">
        <ul>
            <li>Services</li>
            <li>Delivery Fees</li>
            <li>Terms and Condtions</li>
            <li>FAQ</li>
            <li>support@food.com</li>
        </ul>
    </div>

    <div class="bg-white">
            <i class="fa fa-car"></i>
            <p>Food Delivery</p>
            <p>Addis Ababa, Ethiopia<p>
            <p>+251-123-456-789</p>
    </div>
    
    <div class="col-span-2 bg-blue">
        <p>&copy; Food Delivery 2022</p>
        <p>All Rights Reserved</p>
    </div>

</footer>


        